var Twit = require('twit');


var T = new Twit({

  consumer_key: '             ',
  consumer_secret: '             ',
  access_token: '             ',
  access_token_secret: '       ',
})
 
var fs = require('fs');
var util=require('util');
var logFile=fs.createWriteStream('log.json',{flags:'a'});
var logStdout=process.stdout;


var arr=[];
var stream=T.stream('statuses/filter', { track: '@apple', language: 'en' })
 
stream.on('tweet', function (tweet) {
console.log(tweet.text);
})


 console.log=function(){
 
 	logFile.write(util.format.apply(null, arguments)+"\n");
 	logStdout.write(util.format.apply(null, arguments)+"\n");
 }

console.error=console.log;

 //wstream.end();
//T.get('search/data.json', { q: '#Apple since:2011-07-11', count: 50}, function(req, response) {

//response.json(data);

//});
 

