
#-------------Creating GUI------------------#

library(gWidgets2)
options("guiToolkit"="tcltk")

w <- gwindow("Customer Perception Review - Apple (Nov 2016)")
fr <- gframe("Input Customer Reviews", horizontal=FALSE, cont=w) 
fl <- gformlayout(cont=fr)

select_file <- gfilebrowse(cont=fl, label="Select a .csv file: ")

bg_Train <- ggroup(cont=fr)
addSpring(bg_Train)
Train <- gbutton("Train", cont=bg_Train)

bg <- ggroup(cont=fr)
addSpring(bg)
upload <- gbutton("Upload", cont=bg)

bg_Predict <- ggroup(cont=fr)
addSpring(bg_Predict)
Predict <- gbutton("Predict", cont=bg)

#button Events
addHandlerClicked(Train, function(h,...) {
Sentim2()
assign("tweetCARTP", tweetCARTP, envir = .GlobalEnv)
assign("tweetCARTN", tweetCARTN, envir = .GlobalEnv)
assign("tweetCARTNe", tweetCARTNe, envir = .GlobalEnv)
assign("tweets", input, envir = .GlobalEnv)
assign("cc", cc, envir = .GlobalEnv)
assign("tweetsSparse", tweetsSparse, envir = .GlobalEnv)
 })

addHandlerClicked(upload, function(h,...) {
  l <- svalue(select_file) 
  tweetsa = read.csv(l, stringsAsFactor = FALSE)
  assign("tweets1", tweetsa, envir = .GlobalEnv)

})



addHandlerClicked(Predict, function(h,...) {
Sentim(tweets1,tweets,cc,corpus_spec,tweetsSparse,WCP,WCN)
assign("WCP", WCP, envir = .GlobalEnv)
assign("WCN", WCN, envir = .GlobalEnv)
gmessage("Output Files are stored at: ...Tweets", parent = w) 
WCP
WCN

 })


visible(w)<- TRUE
#--------End of GUI code-----------#


#----------Function for training-------------#

Sentim2 <- function (){
#Packages needed

#install tm,SnowballC packages 

install.packages("tm")  #text mining package
install.packages("SnowballC") 

#load package 

library(tm)
library(SnowballC)


#install the related modeling packages 
install.packages("rpart")
install.packages("rpart.plot")
install.packages("caTools",repos="http://cran.cnr.berkeley.edu")

#load the libraries 
library(rpart)
library(rpart.plot)
library(caTools)


# read the .csv file with test and train data into a dataframe 

tweets = read.csv("tweets1.csv", stringsAsFactor = FALSE)

# display the structure of the dataframe tweets 

str(tweets)

summary(tweets)

#filter the negative tweets with an averge score <= -1

tweets$Negative = as.factor(tweets$Avg <= -1)

#filter the Positive tweets with an averge score >= 1

tweets$Positive = as.factor(tweets$Avg >= 1)

#filter the Neutraltweets with an averge score ==0

tweets$Neutral = as.factor(tweets$Avg == 0)

#diplay the table 

table(tweets$Negative)
table(tweets$Positive)
table(tweets$Neutral)


assign("input", tweets, envir = .GlobalEnv)


#create corpus 
#corpus is a collection of documents, tweets needs to be converted into a document for the pre-processing to take place)

corpus = Corpus(VectorSource(tweets$Tweet))

#use tm_map function is tm library to convert all the tweets to lowercase - 
#STEP1 in cleaning
corpus = tm_map(corpus, tolower)

#cleaning step2- remove punctuation

corpus = tm_map(corpus, removePunctuation)

#this command is removing words - stopwords (including the custom words for the present case)


myStopwords <- c(stopwords('english'),"phone", "available", "via", "apple","applebook","apples","neutral","stuff","stock","pay","use","iPhone","emoji","iPay","a's","able","about", "above","according","accordingly","across","actually", "after","afterwards","again","against","ain't", "all","allow","allows","almost","alone", "along","already","also","although","always", "am","among","amongst","an","and", "another","any","anybody","anyhow","anyone", "anything","anyway","anyways","anywhere","apart", "appear","appreciate","appropriate","are","aren't", "around","as","aside","ask","asking", "associated","at","available","away","awfully", "be","became","because","become","becomes", "becoming","been","before","beforehand","behind", "being","believe","below","beside","besides", "best","better","between","beyond","both", "brief","but","by","c'mon","c's", "came","can","can't","cannot","cant", "cause","causes","certain","certainly","changes", "clearly","co","com","come","comes", "concerning","consequently","consider","considering","contain", "containing","contains","corresponding","could","couldn't", "course","currently","definitely","described","despite", "did","didn't","different","do","does", "doesn't","doing","don't","done","down", "downwards","during","each","edu","eg", "eight","either","else","elsewhere","enough", "entirely","especially","et","etc","even", "ever","every","everybody","everyone","everything", "everywhere","ex","exactly","example","except", "far","few","fifth","first","five", "followed","following","follows","for","former", "formerly","forth","four","from","further", "furthermore","get","gets","getting","given", "gives","go","goes","going","gone", "got","gotten","greetings","had","hadn't", "happens","hardly","has","hasn't","have", "haven't","having","he","he's","hello", "help","hence","her","here","here's", "hereafter","hereby","herein","hereupon","hers", "herself","hi","him","himself","his", "hither","hopefully","how","howbeit","however", "i'd","i'll","i'm","i've","ie", "if","ignored","immediate","in","inasmuch", "inc","indeed","indicate","indicated","indicates", "inner","insofar","instead","into","inward", "is","isn't","it","it'd","it'll", "it's","its","itself","just","keep", "keeps","kept","know","known","knows", "last","lately","later","latter","latterly", "least","less","lest","let","let's", "like","liked","likely","little","look", "looking","looks","ltd","mainly","many", "may","maybe","me","mean","meanwhile", "merely","might","more","moreover","most", "mostly","much","must","my","myself", "name","namely","nd","near","nearly", "necessary","need","needs","neither","never", "nevertheless","new","next","nine","no", "nobody","non","none","noone","nor", "normally","not","nothing","novel","now", "nowhere","obviously","of","off","often", "oh","ok","okay","old","on", "once","one","ones","only","onto", "or","other","others","otherwise","ought", "our","ours","ourselves","out","outside", "over","overall","own","particular","particularly", "per","perhaps","placed","please","plus","possible","presumably","probably","provides","que", "quite","qv","rather","rd","re", "really","reasonably","regarding","regardless","regards", "relatively","respectively","right","said","same", "saw","say","saying","says","second", "secondly","see","seeing","seem","seemed", "seeming","seems","seen","self","selves", "sensible","sent","serious","seriously","seven", "several","shall","she","should","shouldn't", "since","six","so","some","somebody", "somehow","someone","something","sometime","sometimes", "somewhat","somewhere","soon","sorry","specified", "specify","specifying","still","sub","such", "sup","sure","ts","take","taken", "tell","tends","th","than","thank", "thanx","that","that's","thats", "the","their","theirs","them","themselves", "then","thence","there","there's","thereafter", "thereby","therefore","therein","theres","thereupon", "these","they","they'd","they'll","they're", "they've","think","third","this","thorough", "thoroughly","those","though","three","through", "throughout","thru","thus","to","together", "too","took","toward","towards","tried","tries","truly","try","trying","twice","two","un","under","unfortunately","unless", "unlikely","until","unto","up","upon", "us","use","used","useful","uses", "using","usually","value","various","very", "via","viz","vs","want","wants", "was","wasn't","way","we","we'd", "we'll","we're","we've","welcome","well", "went","were","weren't","what","what's", "whatever","when","whence","whenever","where", "where's","whereafter","whereas","whereby","wherein", "whereupon","wherever","whether","which","while", "whither","who","who's","whoever","whole", "whom","whose","why","will","willing", "wish","with","within","without","won't", "wonder","would","wouldn't","yes","yet", "you","you'd","you'll","you're","you've", "your","yours","yourself","yourselves","zero","appl","make","amp","dont","fix","yall","google","happen","guys","hey","hook","life","microsoft")

gsub('[0-9]+', '', corpus)


#this command performs stemming function as in - argued, arguing, argue - all is convereted to argue
#use this to display the first tweet to verify if stemming worked
corpus = tm_map(corpus, stemDocument)

corpus = tm_map(corpus, removeWords, myStopwords)
#use this to display the first tweet to verify if stopwords are removed 


#data is clean to some extend 

#Next step - to work with the cleaned data to generate classification MODELs. Work in Progress


# model building starts 

#convert the corpus into PlainTextDocument for the subsequent steps to works. if this command is missing, then the frequencies command is not working! 

corpus <- tm_map(corpus, PlainTextDocument)

frequencies = DocumentTermMatrix(corpus)


# inspect the frequencies 

#inspect(frequencies[1000:1005,505:515])

# this function basically displays words that appear a few times. If the num of words are apppearing less frequenctly, then the predictive power is very low

#findFreqTerms(frequencies, lowfreq=0)

findFreqTerms(frequencies, lowfreq=0)
cc<<-findFreqTerms(frequencies, lowfreq=0)

#create a sparse matrix, assigning this to sparse

#0.995 threshold points out to keep works that appear 0.5% of the tweets, and the remove others.

sparse = removeSparseTerms(frequencies, 0.995)

assign("sparse", sparse, envir = .GlobalEnv)

#create tweetSparse dataframe:
#as.data.frame and as.matrix are two functions

tweetsSparse = as.data.frame(as.matrix(sparse))

#this function assign the proper col names even if the text is starting from the number in the col, this command is critical to use during any text analytic problem.

colnames(tweetsSparse) = make.names(colnames(tweetsSparse))
assign("tweetsSparse", tweetsSparse, envir = .GlobalEnv)

#assign negative variable to the sparse matrix, same as the original tweet data

tweetsSparse$Negative = tweets$Negative

#split the data into test and train
#uses caTools lib

length(tweetsSparse[,1])


splitN = sample.split(tweetsSparse$Negative, SplitRatio=0.7)
trainSparseN = subset(tweetsSparse, splitN==TRUE)
testSparseN = subset(tweetsSparse, splitN==FALSE)

#ready to build models - yayyy!! - data is all clean!! to proceed

#Model1 - CART model - regression tress in classification mode
#method specify as class

tweetCARTN = rpart(Negative ~ ., data=trainSparseN, method="class")

#display the classification tree
prp(tweetCARTN)

#predict the model using predict function
predictCARTN = predict(tweetCARTN, newdata=testSparseN, type="class")

#create confusion matrix

table(testSparseN$Negative, predictCARTN)

#create a baseline table 
table(testSparseN$Negative)

tweetsSparse$Positive = tweets$Positive
tweetsSparse$Neutral = tweets$Neutral



splitP = sample.split(tweetsSparse$Positive, SplitRatio=0.7)
trainSparseP = subset(tweetsSparse, splitP==TRUE)
testSparseP = subset(tweetsSparse, splitP==FALSE)

#ready to build models - yayyy!! - data is all clean!! to proceed

#Model1 - CART model - regression tress in classification mode
#method specify as class

tweetCARTP = rpart(Positive ~ ., data=trainSparseP, method="class")


#predict the model using predict function
predictCARTP = predict(tweetCARTP, newdata=testSparseP, type="class")

#create confusion matrix

table(testSparseP$Positive, predictCARTP)

#create a baseline table 
table(testSparseP$Positive)


splitNe = sample.split(tweetsSparse$Neutral, SplitRatio=0.7)
trainSparseNe = subset(tweetsSparse, splitNe==TRUE)
testSparseNe = subset(tweetsSparse, splitNe==FALSE)

#ready to build models - yayyy!! - data is all clean!! to proceed

#Model1 - CART model - regression tress in classification mode
#method specify as class

tweetCARTNe = rpart(Neutral ~ ., data=trainSparseNe, method="class")

#display the classification tree


#predict the model using predict function
predictCARTNe = predict(tweetCARTNe, newdata=testSparseNe, type="class")

#create confusion matrix

table(testSparseNe$Neutral, predictCARTNe)

#create a baseline table 
table(testSparseNe$Neutral)
assign("tweetCARTP", tweetCARTP, envir = .GlobalEnv)
assign("tweetCARTN", tweetCARTN, envir = .GlobalEnv)
assign("tweetCARTNe", tweetCARTNe, envir = .GlobalEnv)

assign("cc", cc, envir = .GlobalEnv)


}
#----------End of Function for training-------------#



#----------Function for Predicting & Data Visulaisation-------------#
Sentim <- function (tweets1,tweets,cc,corpus_spec,tweetsSparse,WCP,WCN){

#install tm,SnowballC packages 

install.packages("tm")  #text mining package
install.packages("SnowballC") 

#load package 

library(tm)
library(SnowballC)


#install the related modeling packages 
install.packages("rpart")
install.packages("rpart.plot")
install.packages("caTools",repos="http://cran.cnr.berkeley.edu")

#load the libraries 
library(rpart)
library(rpart.plot)
library(caTools)


# read the .csv file with test and train data into a dataframe 

 
tweets1 = read.csv("tweets3.csv", stringsAsFactor = FALSE)
  
tweets = read.csv("tweets1.csv", stringsAsFactor = FALSE)


# display the structure of the dataframe tweets 

str(tweets)
str(tweets1)
summary(tweets)
summary(tweets1)

 tweets[2+(trunc(length(tweetsSparse[,1])*0.8))+2,1]

n=length(tweets1[,1])-1 
i=1
for (i in 1:n) {
#(trunc(length(tweetsSparse[,1])*0.8))+2
    tweets[i+(trunc(length(tweetsSparse[,1])*0.8))+2,1]=tweets1[i,1]
}

tweets[2+(trunc(length(tweetsSparse[,1])*0.8))+2,1]

#filter the negative tweets with an averge score <= -1

tweets$Negative = as.factor(tweets$Avg <= -1)

#filter the Positive tweets with an averge score >= 1

tweets$Positive = as.factor(tweets$Avg >= 1)

#filter the Neutraltweets with an averge score ==0

tweets$Neutral = as.factor(tweets$Avg == 0)

#diplay the table 

table(tweets$Negative)
table(tweets$Positive)
table(tweets$Neutral)


assign("input", tweets, envir = .GlobalEnv)


#create corpus 
#corpus is a collection of documents, tweets needs to be converted into a document for the pre-processing to take place)

corpus = Corpus(VectorSource(tweets$Tweet))

#use tm_map function is tm library to convert all the tweets to lowercase - 
#STEP1 in cleaning
corpus = tm_map(corpus, tolower)

#cleaning step2- remove punctuation

corpus = tm_map(corpus, removePunctuation)




#this command is removing words - stopwords (including the custom words for the present case)


myStopwords <- c(stopwords('english'),"phone", "available", "via", "apple","applebook","apples","neutral","stuff","stock","pay","use","iPhone","emoji","iPay","a's","able","about", "above","according","accordingly","across","actually", "after","afterwards","again","against","ain't", "all","allow","allows","almost","alone", "along","already","also","although","always", "am","among","amongst","an","and", "another","any","anybody","anyhow","anyone", "anything","anyway","anyways","anywhere","apart", "appear","appreciate","appropriate","are","aren't", "around","as","aside","ask","asking", "associated","at","available","away","awfully", "be","became","because","become","becomes", "becoming","been","before","beforehand","behind", "being","believe","below","beside","besides", "best","better","between","beyond","both", "brief","but","by","c'mon","c's", "came","can","can't","cannot","cant", "cause","causes","certain","certainly","changes", "clearly","co","com","come","comes", "concerning","consequently","consider","considering","contain", "containing","contains","corresponding","could","couldn't", "course","currently","definitely","described","despite", "did","didn't","different","do","does", "doesn't","doing","don't","done","down", "downwards","during","each","edu","eg", "eight","either","else","elsewhere","enough", "entirely","especially","et","etc","even", "ever","every","everybody","everyone","everything", "everywhere","ex","exactly","example","except", "far","few","fifth","first","five", "followed","following","follows","for","former", "formerly","forth","four","from","further", "furthermore","get","gets","getting","given", "gives","go","goes","going","gone", "got","gotten","greetings","had","hadn't", "happens","hardly","has","hasn't","have", "haven't","having","he","he's","hello", "help","hence","her","here","here's", "hereafter","hereby","herein","hereupon","hers", "herself","hi","him","himself","his", "hither","hopefully","how","howbeit","however", "i'd","i'll","i'm","i've","ie", "if","ignored","immediate","in","inasmuch", "inc","indeed","indicate","indicated","indicates", "inner","insofar","instead","into","inward", "is","isn't","it","it'd","it'll", "it's","its","itself","just","keep", "keeps","kept","know","known","knows", "last","lately","later","latter","latterly", "least","less","lest","let","let's", "like","liked","likely","little","look", "looking","looks","ltd","mainly","many", "may","maybe","me","mean","meanwhile", "merely","might","more","moreover","most", "mostly","much","must","my","myself", "name","namely","nd","near","nearly", "necessary","need","needs","neither","never", "nevertheless","new","next","nine","no", "nobody","non","none","noone","nor", "normally","not","nothing","novel","now", "nowhere","obviously","of","off","often", "oh","ok","okay","old","on", "once","one","ones","only","onto", "or","other","others","otherwise","ought", "our","ours","ourselves","out","outside", "over","overall","own","particular","particularly", "per","perhaps","placed","please","plus","possible","presumably","probably","provides","que", "quite","qv","rather","rd","re", "really","reasonably","regarding","regardless","regards", "relatively","respectively","right","said","same", "saw","say","saying","says","second", "secondly","see","seeing","seem","seemed", "seeming","seems","seen","self","selves", "sensible","sent","serious","seriously","seven", "several","shall","she","should","shouldn't", "since","six","so","some","somebody", "somehow","someone","something","sometime","sometimes", "somewhat","somewhere","soon","sorry","specified", "specify","specifying","still","sub","such", "sup","sure","ts","take","taken", "tell","tends","th","than","thank", "thanx","that","that's","thats", "the","their","theirs","them","themselves", "then","thence","there","there's","thereafter", "thereby","therefore","therein","theres","thereupon", "these","they","they'd","they'll","they're", "they've","think","third","this","thorough", "thoroughly","those","though","three","through", "throughout","thru","thus","to","together", "too","took","toward","towards","tried","tries","truly","try","trying","twice","two","un","under","unfortunately","unless", "unlikely","until","unto","up","upon", "us","use","used","useful","uses", "using","usually","value","various","very", "via","viz","vs","want","wants", "was","wasn't","way","we","we'd", "we'll","we're","we've","welcome","well", "went","were","weren't","what","what's", "whatever","when","whence","whenever","where", "where's","whereafter","whereas","whereby","wherein", "whereupon","wherever","whether","which","while", "whither","who","who's","whoever","whole", "whom","whose","why","will","willing", "wish","with","within","without","won't", "wonder","would","wouldn't","yes","yet", "you","you'd","you'll","you're","you've", "your","yours","yourself","yourselves","zero","appl","make","amp","dont","fix","yall","google","happen","guys","hey","hook","life","microsoft")


#this command performs stemming function as in - argued, arguing, argue - all is convereted to argue
#use this to display the first tweet to verify if stemming worked
corpus = tm_map(corpus, stemDocument)

corpus = tm_map(corpus, removeWords, myStopwords)
#use this to display the first tweet to verify if stopwords are removed 




#data is clean to some extend 

#Next step - to work with the cleaned data to generate classification MODELs. Work in Progress


# model building starts 

#convert the corpus into PlainTextDocument for the subsequent steps to works. if this command is missing, then the frequencies command is not working! 

corpus <- tm_map(corpus, PlainTextDocument)

frequencies = DocumentTermMatrix(corpus)


# inspect the frequencies 

#inspect(frequencies[1000:1005,505:515])

# this function basically displays words that appear a few times. If the num of words are apppearing less frequenctly, then the predictive power is very low

#findFreqTerms(frequencies, lowfreq=0)

findFreqTerms(frequencies, lowfreq=0)
cc<<-findFreqTerms(frequencies, lowfreq=0)

#create a sparse matrix, assigning this to sparse

#0.995 threshold points out to keep works that appear 0.5% of the tweets, and the remove others.

sparse = removeSparseTerms(frequencies, 0.995)

assign("sparse", sparse, envir = .GlobalEnv)

#create tweetSparse dataframe:
#as.data.frame and as.matrix are two functions

tweetsSparse = as.data.frame(as.matrix(sparse))

#this function assign the proper col names even if the text is starting from the number in the col, this command is critical to use during any text analytic problem.

colnames(tweetsSparse) = make.names(colnames(tweetsSparse))
assign("tweetsSparse", tweetsSparse, envir = .GlobalEnv)

#assign negative variable to the sparse matrix, same as the original tweet data

tweetsSparse$Negative = tweets$Negative



#split the data into test and train
#uses caTools lib


#splitN = sample.split(tweetsSparse$Negative, SplitRatio=0.7)
#trainSparseN = subset(tweetsSparse, splitN==TRUE)
#testSparseN = subset(tweetsSparse, splitN==FALSE)
								

trainSparse = tweetsSparse[1:(trunc(length(tweetsSparse[,1])*0.8)+1),1:length(tweetsSparse)]
testSparse = tweetsSparse[((trunc(length(tweetsSparse[,1])*0.8))+2):(length(tweetsSparse[,1])),1:length(tweetsSparse)]

#ready to build models - yayyy!! - data is all clean!! to proceed

#Model1 - CART model - regression tress in classification mode
#method specify as class

tweetCARTN = rpart(Negative ~ ., data=trainSparse, method="class")

#display the classification tree
prp(tweetCARTN)

#predict the model using predict function
predictCARTN = predict(tweetCARTN, newdata=testSparse, type="class")

#create confusion matrix

table(testSparse$Negative, predictCARTN)

#create a baseline table 
table(testSparse$Negative)
tweetsSparse$Positive = tweets$Positive
tweetsSparse$Neutral = tweets$Neutral
tweetCARTP = rpart(Positive ~ ., data=trainSparse, method="class")

#display the classification tree


#predict the model using predict function
predictCARTP = predict(tweetCARTP, newdata=testSparse, type="class")

#create confusion matrix

table(testSparse$Positive, predictCARTP)

#create a baseline table 
table(testSparse$Positive)



tweetCARTNe = rpart(Neutral ~ ., data=trainSparse, method="class")

#display the classification tree


#predict the model using predict function
predictCARTNe = predict(tweetCARTNe, newdata=testSparse, type="class")

#create confusion matrix

table(testSparse$Neutral, predictCARTNe)

#create a baseline table 
table(testSparse$Neutral)
assign("tweetCARTP", tweetCARTP, envir = .GlobalEnv)
assign("tweetCARTN", tweetCARTN, envir = .GlobalEnv)
assign("tweetCARTNe", tweetCARTNe, envir = .GlobalEnv)

assign("cc", cc, envir = .GlobalEnv)


n=length(tweets1[,1])
n2=2*n 


aaa <- matrix(1:n2, ncol = 2)


i=1
for (i in 1: length(tweets1[,1])){
 aaa[i,1]<-tweets1[i,1]
  if (predictCARTN[[i]]=="TRUE")
   aaa[i,2]= "Negative"
  

  if (predictCARTP[[i]]=="TRUE")
   aaa[i,2]= "Positive"
  
  if (predictCARTNe[[i]]=="TRUE")
   aaa[i,2]= "Neutral"

}
write.csv(aaa, "Your predicted results for the Tweets.csv")
         #----------Code for Wordclouds------------#
aafull<- matrix(1:((2*846)+length(aaa)), ncol = 2)

i=1
for (i in 1:846) {
 aafull[i,1]<-tweets[i,1]
  if (tweets[i,2]<=-1)
   aafull[i,2]= "Negative"
  
  if (tweets[i,2]>=1)
   aafull[i,2]= "Positive"
  
  if (tweets[i,2]==0)
   aafull[i,2]= "Neutral"
 }
for (i in 1:length(tweets1[,1])) {
 aafull[i+846,1]<-aaa[i,1]
 aafull[i+846,2]<-aaa[i,2]
  }

II=as.data.frame(as.matrix(aafull))

IIPos <- II[ which(II$V2=="Positive"),] 

IINeg <- II[ which(II$V2=="Negative"),] 

IINeu <- II[ which(II$V2=="Neutral"),] 


corpusP = Corpus(VectorSource(IIPos$V1))
corpusP = tm_map(corpusP, tolower)
corpusP = tm_map(corpusP, removePunctuation)


corpusP = tm_map(corpusP, stemDocument)
corpusP = tm_map(corpusP, removeWords, myStopwords)
corpusP <- tm_map(corpusP, PlainTextDocument)

frequenciesP = DocumentTermMatrix(corpusP)

corpusN = Corpus(VectorSource(IINeg$V1))

#use tm_map function is tm library to convert all the tweets to lowercase - 
#STEP1 in cleaning
corpusN = tm_map(corpusN, tolower)

#cleaning step2- remove punctuation

corpusN = tm_map(corpusN, removePunctuation)

corpusN<<-corpusN

corpusN = tm_map(corpusN, stemDocument)

corpusN = tm_map(corpusN, removeWords, myStopwords)


corpusN <- tm_map(corpusN, PlainTextDocument)

frequenciesN = DocumentTermMatrix(corpusN)

corpusNe = Corpus(VectorSource(IINeu$V1))

#use tm_map function is tm library to convert all the tweets to lowercase - 
#STEP1 in cleaning
corpusNe = tm_map(corpusNe, tolower)

#cleaning step2- remove punctuation

corpusNe = tm_map(corpusNe, removePunctuation)


corpusNe = tm_map(corpusNe, stemDocument)

corpusNe = tm_map(corpusNe, removeWords, myStopwords)


corpusNe <- tm_map(corpusNe, PlainTextDocument)

frequenciesNe = DocumentTermMatrix(corpusNe)


myDtmP <- TermDocumentMatrix(corpusP, control = list(minWordLength = 1))
mP <- as.matrix(myDtmP)
 # calculate the frequency of words
 vP <- sort(rowSums(mP), decreasing=TRUE)
myNamesP <- names(vP)

text <- matrix(1:length(vP), ncol = 1)
size <- matrix(1:length(vP), ncol = 1)

for (i in 1:(length(vP))){
if (vP[[i]]>=2)
 text[i]=myNamesP[i] 
if (vP[[i]]>=2)
size[i]=vP[[i]]
if (vP[[i]]<2) 
text[i]=""
if (vP[[i]]<2) 
  size[i]="" 
}

 dP <- data.frame(text, size)
 dP<-dP[!(dP$text=="" & dP$size==""),]


myDtmN <- TermDocumentMatrix(corpusN, control = list(minWordLength = 1))
mN <- as.matrix(myDtmN)
 # calculate the frequency of words
 vN <- sort(rowSums(mN), decreasing=TRUE)
myNamesN <- names(vN)
myDtmN <- as.matrix(myDtmN)

# change it to a Boolean matrix
myDtmN[myDtmN>=1] <- 1
# transform into a term-term adjacency matrix
 termMatrix <- myDtmN%*% t(myDtmN)
# inspect terms numbered 5 to 10

termMatrix[5:10,5:10]


text <- matrix(1:length(vN), ncol = 1)
size <- matrix(1:length(vN), ncol = 1)

for (i in 1:(length(vN))){
if (vN[[i]]>=2)
 text[i]=myNamesN[i] 
if (vN[[i]]>=2)
size[i]=vN[[i]]
if (vN[[i]]<2) 
text[i]=""
if (vN[[i]]<2) 
  size[i]="" 
}

 dN <- data.frame(text, size)
 dN<-dN[!(dN$text=="" & dN$size==""),]

myDtmNe <- TermDocumentMatrix(corpusNe, control = list(minWordLength = 1))
mNe <- as.matrix(myDtmNe)
 # calculate the frequency of words
 vNe <- sort(rowSums(mNe), decreasing=TRUE)
myNamesNe <- names(vNe)

text <- matrix(1:length(vNe), ncol = 1)
size <- matrix(1:length(vNe), ncol = 1)

for (i in 1:(length(vNe))){
if (vNe[[i]]>=2)
 text[i]=myNamesNe[i] 
if (vNe[[i]]>=2)
size[i]=vNe[[i]]
if (vNe[[i]]<2) 
text[i]=""
if (vNe[[i]]<2) 
  size[i]="" 
}

 dNe <- data.frame(text, size)
 dNe<-dNe[!(dNe$text=="" & dNe$size==""),]

dP[, 2] <- as.numeric(as.character( dP[, 2] ))
dN[, 2] <- as.numeric(as.character( dN[, 2] ))
dNe[, 2] <- as.numeric(as.character( dNe[, 2] ))


 assign("dP", dP, envir = .GlobalEnv)
 assign("dN", dN, envir = .GlobalEnv)
 assign("dNe", dNe, envir = .GlobalEnv)

install.packages("wordcloud2")
library(wordcloud2)
WCP<<- wordcloud2(dP, figPath = "C:/Users/aswin/Documents/git1125/Final_Project/Tweets/apple.jpg", size = 1,color = "blue")
WCN<<-wordcloud2(dN, figPath = "C:/Users/aswin/Documents/git1125/Final_Project/Tweets/apple.jpg", size = 1,color = "red")

assign("WCP", WCP, envir = .GlobalEnv)
assign("WCN", WCN, envir = .GlobalEnv)
             #----------End of Code for Wordclouds------------#

#----------Code for Piechart------------#
# 3D Exploded Pie Chart
install.packages("plotrix")
library(plotrix)
slices <- c(length(IIPos[,1]), length(IINeg[,1]), length(IINeu[,1])) 
lbls <- c("Positive", "Negative", "Neutral")
pct <- round(slices/sum(slices)*100)
lbls <- paste(lbls, pct) # add percents to labels 
lbls <- paste(lbls,"%",sep="") # ad % to labels 
png("Overview of Brand Perception.png", width=1280,height=800)
pie3D(slices,labels=lbls,explode=0.1,
  	main="Overview of Brand Perception")


#----------End of Code for Piechart------------#



         #----------Code for Network Graph - Positive------------#
Matr <- matrix(1:1602, ncol = 3)
ss=5
myDtmN <- as.matrix(myDtmN)
# change it to a Boolean matrix
myDtmN[myDtmN>=1] <- 1
termMatrix <- myDtmN %*% t(myDtmN)
num=0
for (i in 1:length(termMatrix[,1])){
  for (j in 1:length(termMatrix[1,])){
if (termMatrix[i,j]>=ss)
num=num+1 
Matr[num,][1]=colnames(termMatrix)[i]
if (termMatrix[i,j]>=ss)
Matr[num,][2]=row.names(termMatrix)[j]
if (termMatrix[i,j]>=ss)
Matr[num,][3]=termMatrix[i,j]
}
}

Matr<-Matr[-num+1:-534,]

Matr<-data.frame(Matr)
      


library(networkD3)
colnames(Matr) <- c("SourceName", "TargetName", "Weight")
gD <- igraph::simplify(igraph::graph.data.frame(Matr, directed=FALSE))

nodeList <- data.frame(ID = c(0:(igraph::vcount(gD) - 1)),nName = igraph::V(gD)$name)

getNodeID <- function(x){ which(x == igraph::V(gD)$name) - 1 }

Matr <- plyr::ddply(Matr,.variables = c("SourceName", "TargetName", "Weight"), 
function (x) data.frame(SourceID = getNodeID(x$SourceName), TargetID = getNodeID(x$TargetName)))


nodeList <- cbind(nodeList, nodeDegree=igraph::degree(gD, v = igraph::V(gD), mode = "all"))



# Calculate betweenness for all nodes

betAll <- igraph::betweenness(gD, v = igraph::V(gD), directed = FALSE) / (((igraph::vcount(gD) - 1) * (igraph::vcount(gD)-2)) / 2)

betAll.norm <- (betAll - min(betAll))/(max(betAll) - min(betAll))

nodeList <- cbind(nodeList, nodeBetweenness=100*betAll.norm) # We are scaling the value by multiplying it by 100 for visualization purposes only (to create larger nodes)

rm(betAll, betAll.norm)



#Calculate Dice similarities between all pairs of nodes

dsAll <- igraph::similarity.dice(gD, vids = igraph::V(gD), mode = "all")



F1 <- function(x) {data.frame(diceSim = dsAll[x$SourceID +1, x$TargetID + 1])}

edgeList <- plyr::ddply(Matr, .variables=c("SourceName", "TargetName", "Weight", "SourceID", "TargetID"), 
function(x) data.frame(F1(x)))



rm(dsAll, F1, getNodeID, gD)


edgeList<-Matr

Netgraph_N <- networkD3::forceNetwork(Links = edgeList, Nodes = nodeList, 
                        Source = "SourceID", # ID of source node 
                        Target = "TargetID", # ID of target node
                        Value = "Weight", # value from the edge list (data frame) that will be used to value/weight relationship amongst nodes
                        NodeID = "nName", # value from the node list (data frame) that contains node description we want to use (e.g., node name)
                        Nodesize = "nodeBetweenness",  # value from the node list (data frame) that contains value we want to use for a node size
                        Group = "nodeDegree",  # value from the node list (data frame) that contains value we want to use for node color
                        height = 500, 
                        width = 1000,  
                        fontSize = 20,
                        linkDistance = networkD3::JS("function(d) { return 10*d.value; }"), # Function to determine distance between any two nodes, uses variables already defined in forceNetwork function (not variables from a data frame)
                        linkWidth = networkD3::JS("function(d) { return d.value/5; }"),# Function to determine link/edge thickness, uses variables already defined in forceNetwork function (not variables from a data frame)
                        opacity = 0.85, # opacity
                        zoom = TRUE, # ability to zoom when click on the node
                        opacityNoHover = 0.1)


Netgraph_N 
networkD3::saveNetwork(Netgraph_N, "Netgraph_N.html", selfcontained = FALSE)

         #----------Code for Network Graph - Positive------------#
MatrP <- matrix(1:1602, ncol = 3)
ss=3
myDtmP <- as.matrix(myDtmP)
# change it to a Boolean matrix
myDtmP[myDtmP>=1] <- 1
termMatrix <- myDtmP %*% t(myDtmP)
num=0
for (i in 1:length(termMatrix[,1])){
  for (j in 1:length(termMatrix[1,])){
if (termMatrix[i,j]>=ss)
num=num+1 
MatrP[num,][1]=colnames(termMatrix)[i]
if (termMatrix[i,j]>=ss)
MatrP[num,][2]=row.names(termMatrix)[j]
if (termMatrix[i,j]>=ss)
MatrP[num,][3]=termMatrix[i,j]
}
}

MatrP<-MatrP[-num+1:-534,]

MatrP<-data.frame(MatrP)
      


library(networkD3)
colnames(MatrP) <- c("SourceName", "TargetName", "Weight")
gD <- igraph::simplify(igraph::graph.data.frame(MatrP, directed=FALSE))

nodeList <- data.frame(ID = c(0:(igraph::vcount(gD) - 1)),nName = igraph::V(gD)$name)

getNodeID <- function(x){ which(x == igraph::V(gD)$name) - 1 }

MatrP <- plyr::ddply(MatrP,.variables = c("SourceName", "TargetName", "Weight"), 
function (x) data.frame(SourceID = getNodeID(x$SourceName), TargetID = getNodeID(x$TargetName)))


nodeList <- cbind(nodeList, nodeDegree=igraph::degree(gD, v = igraph::V(gD), mode = "all"))



# Calculate betweenness for all nodes

betAll <- igraph::betweenness(gD, v = igraph::V(gD), directed = FALSE) / (((igraph::vcount(gD) - 1) * (igraph::vcount(gD)-2)) / 2)

betAll.norm <- (betAll - min(betAll))/(max(betAll) - min(betAll))

nodeList <- cbind(nodeList, nodeBetweenness=100*betAll.norm) # We are scaling the value by multiplying it by 100 for visualization purposes only (to create larger nodes)

rm(betAll, betAll.norm)



#Calculate Dice similarities between all pairs of nodes

dsAll <- igraph::similarity.dice(gD, vids = igraph::V(gD), mode = "all")



F1 <- function(x) {data.frame(diceSim = dsAll[x$SourceID +1, x$TargetID + 1])}

edgeList <- plyr::ddply(MatrP, .variables=c("SourceName", "TargetName", "Weight", "SourceID", "TargetID"), 
function(x) data.frame(F1(x)))



rm(dsAll, F1, getNodeID, gD)


edgeList<-MatrP

Netgraph_P <- networkD3::forceNetwork(Links = edgeList, Nodes = nodeList, 
                        Source = "SourceID", # ID of source node 
                        Target = "TargetID", # ID of target node
                        Value = "Weight", # value from the edge list (data frame) that will be used to value/weight relationship amongst nodes
                        NodeID = "nName", # value from the node list (data frame) that contains node description we want to use (e.g., node name)
                        Nodesize = "nodeBetweenness",  # value from the node list (data frame) that contains value we want to use for a node size
                        Group = "nodeDegree",  # value from the node list (data frame) that contains value we want to use for node color
                        height = 500, 
                        width = 1000,  
                        fontSize = 20,
                        linkDistance = networkD3::JS("function(d) { return 10*d.value; }"), # Function to determine distance between any two nodes, uses variables already defined in forceNetwork function (not variables from a data frame)
                        linkWidth = networkD3::JS("function(d) { return d.value/5; }"),# Function to determine link/edge thickness, uses variables already defined in forceNetwork function (not variables from a data frame)
                        opacity = 0.85, # opacity
                        zoom = TRUE, # ability to zoom when click on the node
                        opacityNoHover = 0.1)


Netgraph_P 
networkD3::saveNetwork(Netgraph_P, "Netgraph_P.html", selfcontained = FALSE)


}

#----------Function for Predicting & Data Visulaisation-------------#
