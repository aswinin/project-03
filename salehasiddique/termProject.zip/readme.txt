All libraries are provided. 
To run this follow the steps:

<Starting the Server>
1. Navigate to folder source/js 
2. Git Bash here and in the command line type below command to start the server:
node index.js  

<Launching the client side page>
1. Navigate to folder source
2. Launch index.html in Chrome

<Using the client side page>
Enter a valid amazon product URL in index.html, click on 'Analyze Reviews' 
e.g. 'https://www.amazon.com/Professional-Ceramic-Negative-Speeds-Button/dp/B016D4UE1Q/ref=sr_1_16_s_it?s=beauty&ie=UTF8&qid=1480667379&sr=1-16&keywords=hair+dryer'