//code for implementing node.js server is from http://baboon.ir/uploads/2015/06/The.Node_.Beginner.Book_.pdf

var server = require("./server");
var router = require("./router");

var requestHandlers = require("./requestHandlers");
var handle = {};

handle["/"] = requestHandlers.start;
handle["/start"] = requestHandlers.start;
handle["/upload"] = requestHandlers.upload;
server.start(router.route, handle);
