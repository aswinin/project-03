var http = require("http");
var url = require("url");
var querystring = require("querystring");

var formidable = require("formidable"); //source code for using formidable taken from:https://www.sitepoint.com/creating-and-handling-forms-in-node-js/
const util = require('util');

var formParameters=[]; //array, first element will be amazonURL, second will be analyzeReviewsOption

function start(route, handle) {
	function onRequest(request, response) {
	
	var pathname = url.parse(request.url).pathname;

	//console.log("Request for URL" + querystring.parse(request).amazonURL);


	//console.log("Request for URL"+ request.body.amazonURL);
	console.log("Request for " + pathname + " received.");

	var form = new formidable.IncomingForm();

    form.parse(request, function (err, fields, files) {

    	
    	formParameters= [fields.amazonURL];
        
        console.log("Received amazonURL: "+ fields.amazonURL);
        

        response.writeHead(200, {"Content-Type": "text/html"});
	
		var content = route(handle, pathname, formParameters);
		response.write(content);
		response.end();


        //response.writeHead(200, {
        //    'content-type': 'text/plain'
        //});
        //response.write('received the data:\n\n');
        //response.end(util.inspect({
            //fields: fields,
            //files: files
        //}));
    });







	//

	
	}
	http.createServer(onRequest).listen(8888);
	console.log("Server has started.");

}
exports.start = start;
