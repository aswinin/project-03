'use strict';

var AlchemyLanguageV1 = require('watson-developer-cloud/alchemy-language/v1');
var alchemy_language = new AlchemyLanguageV1({
  api_key: '1d8fd181c85da29494f272a530edd780a3d88ee3'
});

var reviewsCrawler = require('amazon-reviews-crawler');

//var reviewParser = require('./review-parser.js');

var reviews; //JSON object with reviews
var review; //dealing with a single review

var textOfAllReviews; 



function start(formParameters) {
	console.log("Request handler 'start' was called.");

	console.log("Form parameter received is:" + formParameters[0] );

	var url = formParameters[0];

	var productID = getProductID(url);

	reviewsCrawler(productID, function(err, reviews){
    if(err) throw err;
    console.log("reviews are "+ reviews.reviews.length);
    console.log(reviews);

    //go through all the parsed reviews, collecting the text in one variable 
	var i;
	for (i=0; i<reviews.reviews.length;i++){
		    	textOfAllReviews += " ";
		    	textOfAllReviews += reviews.reviews[i].text;
	}
	
	console.log("length of text" + textOfAllReviews.length);	    
	console.log("Printing all reviews now");
	console.log(textOfAllReviews);

	// Combined call
	// ------------
	var parameters = {
	  extract: 'entities,keywords',
	  sentiment: 1,
	  maxRetrieve: 1000,
	  //url: 'https://www.ibm.com/us-en/'
	  //url: 'https://news.google.com/'
	  text: textOfAllReviews
	};


	alchemy_language.combined(parameters, function (err, response) {
	  if (err)
	    console.log('error:', err);
	  else{
	    console.log(JSON.stringify(response, null, 2));
	    
		
	  }

	}); 




	});

	//use the productID to parse reviews from Amazon site
	/*reviews = reviewParser.getReviewsForProductId(productID, function (err, response) {
	  if (err)
	    console.log('error:', err);
	  else{
	    console.log(JSON.stringify(response, null, 2));
	    textOfAllReviews=""; //initialise it to blank string
    
		//go through all the parsed reviews, collecting the text in one variable 
		var i;
		for (i=0; i<reviews.length();i++){
		    	textOfAllReviews += " ";
		    	textOfAllReviews += review[i].text;
		}
		    
		console.log("printing all reviews now");
		console.log(textOfAllReviews);

		
	  }

	}); */

    
	
	
	/*alchemy_language.combined(parameters, function (err, response) {
	  if (err)
	    console.log('error:', err);
	  else{
	    console.log(JSON.stringify(response, null, 2));
		
	  }

	}); */

	
var htmlReturn = "<html><body><h1>See Analysis Results output in console<h1></body></html>";
    	return htmlReturn;
	
}


function upload() {
	//console.log("Request handler 'upload' was called.");
	//return "Hello Upload";
	console.log("Request handler 'upload' was called.");
	response.writeHead(200, {"Content-Type": "text/plain"});
	response.write("You've sent: " + postData);
	response.end();
}
exports.start = start;
exports.upload = upload;


//sourced from http://stackoverflow.com/questions/1764605/scrape-asin-from-amazon-url-using-javascript
//function returns 10 character ProductID from an Amazon URL
function getProductID (url){

	var regex = RegExp("/([A-Z0-9]{10})(?:[/?]|$)");
	var m = url.match(regex);
	if (m) { 
		m[0] = m[0].slice(1,11); //get the 10 character Product ID - removes enclosing slashes
		console.log("ProductID extracted from URL:" + m[0]);
		return m[0];
	}


}