# NK model generation adapted from Maciej Workiewicz (2014) https://github.com/Mac13kW/NK_model
import numpy as np
import itertools
import random
import copy
from time import time


# interaction matrix (epistasis)
def matrix_rand(N, K):
    Int_matrix_rand = np.zeros((N, N))
    for aa1 in np.arange(N):
        Indexes_1 = range(N)
        Indexes_1.remove(aa1)
        np.random.shuffle(Indexes_1)
        Indexes_1.append(aa1)
        Chosen_ones = Indexes_1[-(K+1):]  # this takes the last K+1 indexes
        for aa2 in Chosen_ones:
            Int_matrix_rand[aa1, aa2] = 1
    return(Int_matrix_rand)


def powerkey(N):
    Power_key = np.power(2, np.arange(N - 1, -1, -1))
    return(Power_key)


def nkland(N):
    NK_land = np.random.rand(2**N, N)
    return(NK_land)


def calc_fit(N, NK_land, inter_m, Current_position, Power_key):
    Fit_vector = np.zeros(N)
    for ad1 in np.arange(N):
        Fit_vector[ad1] = NK_land[np.sum(Current_position * inter_m[ad1]
                                         * Power_key), ad1]
    return(Fit_vector)


def comb_and_values(N, NK_land, Power_key, inter_m):
    """
    Calculates values for all combinations on the landscape.
    - the first N columns are for the combinations of N decision variables DV
    - the second N columns are for the contribution values of each DV
    - the next valuer is for the total fit (avg of N contributions)
    - the last one is to find out whether it is the local peak (0 or 1)
    """
    Comb_and_value = np.zeros((2**N, N*2+2))
    c1 = 0  # starting counter for location
    for c2 in itertools.product(range(2), repeat=N):
        '''
        this takes time so carefull
        '''
        Combination1 = np.array(c2)  # taking each combination
        fit_1 = calc_fit(N, NK_land, inter_m, Combination1, Power_key)
        Comb_and_value[c1, :N] = Combination1  # combination and values
        Comb_and_value[c1, N:2*N] = fit_1
        Comb_and_value[c1, 2*N] = np.mean(fit_1)
        c1 = c1 + 1
    for c3 in np.arange(2**N):  # now let's see if that is a local peak
        loc_p = 1  # assume it is
        for c4 in np.arange(N):  # check for the neighbourhood
            new_comb = Comb_and_value[c3, :N].copy()
            new_comb[c4] = abs(new_comb[c4] - 1)
            if ((Comb_and_value[c3, 2*N] <
                 Comb_and_value[np.sum(new_comb*Power_key), 2*N])):
                loc_p = 0  # if smaller than the neighbour then not peak
        Comb_and_value[c3, 2*N+1] = loc_p
    return(Comb_and_value)


# NK space parameters. N=15 and K=5 takes about 16 seconds to make.
N = 12
K = 3
landscapes = 1  # number of landscapes to produce (use 100 or less for testing)

NKland = [[]]; #because i'm not making any N=0 or N=1 spaces

for N in range(2,11):
	for K in range (0,11):
		# Generate NK Space
		Power_key = powerkey(N)
		NK = np.zeros((2**N, N*2+2))
		NKtrunc = np.empty([2**N,2], dtype="S10") #small NK just to keep string and val
		start = time()
		NK_land = nkland(N)
		Int_matrix = matrix_rand(N, K)
		NK = comb_and_values(N, NK_land, Power_key, Int_matrix)
		NKend = time()
		print(' time to make NK: ' + str("%.2f" % (NKend-start)) + ' sec')
		for i in range (0,2**N): #for every string
			istring = '';
			for j in range(0,N): #for every dimension in string
				istring = istring + str(int(NK[i][j])); #concatenates idea string. i hope.
			NKtrunc[i][0] = istring;
			print(NKtrunc[i][0])
			NKtrunc[i][1] = str(NK[i][2*N]);
		NKland[N-2].append([]);
		NKland[N-2][K] = NKtrunc;
		print('N: '+str(N))
		print('K: '+str(K))
		np.savetxt('N'+str(N)+'-K'+str(K)+'.csv', NKtrunc, delimiter=",", fmt="%s")
	NKland.append([]);
