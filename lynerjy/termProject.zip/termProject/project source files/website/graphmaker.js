var nkmatrix = [];
var globalnval = null;
var globalkval = null;
var swgraph = [[]];
var numgraphs = 0;
var gn = 0;
var currid = null;
var avevals = [];
var abval = "";
var eval = "";
var currentlyplaying = 0;

// var items =[];
var twgraph = randomgraph.WattsStrogatz.alpha(40,3,0.01);
    for (var i=0; i<40; i++){
        twgraph.nodes[i].id=i;
        twgraph.nodes[i].value=Math.random(); // REPLACE WITH RANDOM NK VALUE
    }


initialize(twgraph,1);
// nkitems = csvajax("N2-K0.txt");

function csvajax(filename)
{
     var result = null;
     $.ajax({
        url: filename,
        type: 'get',
        dataType: 'text',
        async: false,
        success: function(data) {
            result = data;
        } 
     });
     nkitems = result.split('\n'); //isn't there a way where i don't have to make this a globalvar...
      for (var i=0; i<nkitems.length; i++){
        nkitems[i] = nkitems[i].split(',');
      }
      nkitems = nkitems.slice(0,nkitems.length-1)
     return nkitems;
}

function closeabout(){
  document.getElementById("div1").style.visibility="visible";
  document.getElementById("about").style.visibility="hidden";
}

function showabout(){
  document.getElementById("about").style.visibility="visible";
}

function makegraph(){
    var swnval = parseInt($('#swnval').val());
    var swkval = parseInt($('#swkval').val());
    var swbval = parseFloat($('#swbval').val());
    if (isNaN(swnval)||swnval<1){alert ('Value for N must be a positive integer'); return;}
    if (isNaN(swkval)||swkval<1){alert ('Value for K must be a positive integer'); return;}
    if (isNaN(swbval)||swbval>1||swbval<0){alert ('Value for b must be between 0 and 1'); return;}

    gn = numgraphs;
    swgraph[gn][0] = randomgraph.WattsStrogatz.alpha(swnval,swkval,swbval);
    for (var i=0; i<swnval; i++){
        swgraph[gn][0].nodes[i].id=i;
        swgraph[gn][0].nodes[i].value=1; // replace with starter grey value or something
    }

    // console.log(swgraph)

    var svg = d3.select("#svg1"),
    width = +svg.attr("width"),
    height = +svg.attr("height");


    var simulation = d3.forceSimulation()
        .force("link", d3.forceLink().id(function(d) { return d.id; }))
        .force("charge", d3.forceManyBody())
        .force("center", d3.forceCenter(width / 2, height / 2));

      refgraph = JSON.parse(JSON.stringify(swgraph[gn][0]))
    initialize(refgraph,0) // DON'T CORRUPT IT YET.

   document.getElementById("div2").style.visibility="visible";
   document.getElementById("div2").style.opacity="1";
  document.getElementById("div2").style.pointerEvents="all";

}

function getlandscape(){
  var nval = parseInt($('#nval').val());
  var kval = parseInt($('#kval').val());
  if (isNaN(nval)||nval<2 || nval>10){alert ('Value for N must be a positive integer between 2 and 10'); return;}
  if (isNaN(kval)||kval<0 || kval>=nval || kval>9){alert ('Value for K must be a positive integer between 0 and 9, and must be less than N.'); return;}
  // window.open('popup.html', "NK Landscape Values", "height=500,width=500")

  globalnval = nval;
  globalkval = kval;
  document.getElementById("div3").style.visibility="visible";
    document.getElementById("div3").style.opacity="1";
  document.getElementById("div3").style.pointerEvents="all";


    //1. Get/check the NK
  var nkfilestring = "NKs/N"+globalnval.toString()+"-K"+globalkval.toString()+".txt";
  thisnk = csvajax(nkfilestring);
  // assign random starting beliefs (i.e. random binary string)
  var nlength = swgraph[gn][0].nodes.length; // number of nodes in the network
  for (var i=0; i<nlength; i++){
    var randval = Math.round((thisnk.length-1)*Math.random());
    // console.log(randval)
    // set for first timestep
    swgraph[gn][0].nodes[i].ideastring = thisnk[randval][0];
    swgraph[gn][0].nodes[i].value= parseFloat(thisnk[randval][1]);
  }


      refgraph = JSON.parse(JSON.stringify(swgraph[gn][0]))
    initialize(refgraph,0)

}

function setadopt(){
  abval = $('input[name=adoption]:checked').val();
  // abval = $('#abval').val();
  // eval = $('#eval').val();
  eval = $('input[name=adoption]]:checked').val();

  if (abval==1){
    eval = 1;
  }
  document.getElementById("div4").style.visibility="visible";
    document.getElementById("div4").style.opacity="1";
  document.getElementById("div4").style.pointerEvents="all";
}


function playsim(){
    if (currentlyplaying==1){
      clearInterval(window.myTimer);
      currentlyplaying = 0;
    } else {
      window.myTimer = setInterval(function(){ changesim('forward'); }, 500);
      currentlyplaying = 1;
    }


}

function pausesim(){
    clearInterval(window.myTimer)
    return;
}

function changesim(buttonid){
    var simname = $('input[name=fu]:checked').val()
    if (simname==undefined){
        alert('There is no simulation loaded. Run a simulation first.');
        return;
    }

    var currentt = parseInt($('#changeslide').val()); // current time step
    // console.log('currentt:'+currentt)
    var maxt = swgraph[gn].length // BUT IT SHOULD BE THE FILE'S T.
    if (buttonid == 'reverse'){
        if (currentt>=1){
            var nextt = currentt-1;
        } else{
            var nextt = currentt;
        }
    } else {
        if (currentt==maxt-1){
          // console.log('maxreached')
            currentlyplaying = 0;
            clearInterval(window.myTimer);
            var nextt = currentt
        } else {
          var nextt = currentt+1;
        }
    }
    // console.log('nt:'+nextt)
    $('#changeslide').val(nextt);
    document.getElementById("currenttshown").innerHTML = "t="+nextt;
    
        var simname = $('input[name=fu]:checked').val()
    var simid = $('input[name=fu]:checked').attr('id')
    if (simid!=currid){
      currid = simid;

      initialize(swgraph[simid][0],0)
    } else{
    dofunction(nextt)
  }
    // loadgraph(graph(t+1)) or something... draw the graph again for given time
    // 
}

function opensim(){
  // document.getElementById("div1").style.visibility="visible";

  document.getElementById("div1").style.opacity="1";
  document.getElementById("div1").style.pointerEvents="all";
  
}

function loadsim(){
    var simname = $('input[name=fu]:checked').val()
    var simid = $('input[name=fu]:checked').attr('id')
    if (simid!=currid){
      currid = simid;

      initialize(swgraph[simid][0],0)
    }
    gn = currid

    var simtime = swgraph[simid].length
    // console.log(currid)
    document.getElementById("endtime").innerHTML = simtime-1;
    document.getElementById("currenttshown").innerHTML = "t=0";
    $('#changeslide').val(0); 
    $('#changeslide').attr('max', simtime-1); 

    if (simid==undefined){
        alert('There are no simulations to load. Run a simulation first.');
    } else {
        document.getElementById("currentsimshown").innerHTML = simname;
    }
    document.getElementById("simbox").style.visibility="visible";


    linegraph(avevals[simid]);
}

function runsim(){
    var simname = $('#simname').val();
    var simtime = parseInt($('#simtime').val());
    if (simname==""){ alert ('Name this simulation'); return;}
    if (isNaN(simtime)||simtime<1){alert ('Value for timesteps must be a positive integer'); return;}

    document.getElementById("endtime").innerHTML = simtime-1;
    $('#changeslide').attr('max', simtime-1); 
    $('#changeslide').val(0); 
    document.getElementById("currenttshown").innerHTML = "t=0";
    avevals.push([]);
    // some sort of 'loading' pinwheel

    //1. NK done in getlanscape.
    var nlength = swgraph[gn][0].nodes.length; // number of nodes in the network

    // Build the adjacency matrix
    // empty matrix of 0s
    var adjm = new Array(nlength);
    for (var i = 0; i < nlength; i++) {
      adjm[i] = new Array(nlength).fill(0);
    }
    // console.log(adjm)
    // fill with 1s
    for (var e=0; e<swgraph[gn][0].edges.length; e++){
      var source = swgraph[gn][0].edges[e].source;
      var target = swgraph[gn][0].edges[e].target;
      // console.log(source)
      adjm[source][target] = 1;
      adjm[target][source] = 1;
    }

    //3. Get/run the network
    for (var k=0; k<simtime-1; k++){ // loop across all the simulation timesteps
      swgraph[gn].push({});
      swgraph[gn][k+1].nodes = JSON.parse(JSON.stringify(swgraph[gn][k].nodes))
      // swgraph[gn][k+1].edges = JSON.parse(JSON.stringify(swgraph[gn][k].edges))
      swgraph[gn][k+1].edges = swgraph[gn][k].edges

      //initialize value storage
      avevals[gn].push({});
      avevals[gn][k].value = 0;
      
      for (var i=0; i<nlength; i++){ // loop across everynode
        // find all the friends
        var friends = adjm[i];
        for (var j=0; j<nlength; j++){
          if (adjm[i][j]==1 && (swgraph[gn][k].nodes[j].value > swgraph[gn][k].nodes[i].value)) { //replace string if you find one with higher value
            if (eval==1){
              var diffp = 1;
              if (abval==1){
                var stringa = swgraph[gn][k].nodes[i].ideastring;
                var stringb = swgraph[gn][k].nodes[j].ideastring;
                var diffval = 0;
                // count differences
                for (var q=0;q<globalnval;q++){
                  if (stringa[q]!=stringb[q]){
                    diffval++;
                    // SHOULD DO THE RANDOM BOOLEAN ADOPTION IN HERE
                  }
                }
                diffp = diffval/globalnval; //% difference between planned adoptee
              }

              // sparse out ideastring
              var tempstring = swgraph[gn][k].nodes[j].ideastring;
              var tlength = tempstring.length;
              var randt = Math.round(diffp*tlength*Math.random()); // how many indices it will change
              var newstring = tempstring;
              // change random dimension(s) in string
              for (var m=0; m<randt; m++){
                var otherrand = Math.round(tlength*Math.random());
                newstring[otherrand] = (+ !Boolean(tempstring[otherrand])).toString();
              }
              var nkind = parseInt(newstring, 2)
              // pull new value
              swgraph[gn][k+1].nodes[i].ideastring = thisnk[nkind][0];
              swgraph[gn][k+1].nodes[i].value= parseFloat(thisnk[nkind][1]);
            } else {
              swgraph[gn][k+1].nodes[i].ideastring = swgraph[gn][k].nodes[j].ideastring;
              swgraph[gn][k+1].nodes[i].value = swgraph[gn][k].nodes[j].value;
            }
          }
        }
        avevals[gn][k].timestep = k;
        avevals[gn][k].value = avevals[gn][k].value + swgraph[gn][k].nodes[i].value;
        // console.log(avevals[gn][k].value)
      }
      avevals[gn][k].value = (avevals[gn][k].value/nlength).toFixed(2)
      
    }

    addsim(); // add sim to the list
    var simid = $('input[name=fu]:checked').attr('id');
    linegraph(avevals[simid])
    numgraphs++; // change graph numbers so it'll store another one

    swgraph.push([[]]);
     $("#simparameters")[0].reset(); // reset the simulation parameters
     $("#NK")[0].reset(); // reset$("#simparameters")[0].reset() the simulation parameters
     $("#networkparameters")[0].reset(); // reset$("#simparameters")[0].reset() the simulation parameters
     $("#adoption")[0].reset(); // reset adoption params

     document.getElementById("div5").style.visibility="visible"; // make the next thing visible
    document.getElementById("div1").style.opacity="0.5";
    document.getElementById("div1").style.pointerEvents="none";
    document.getElementById("div2").style.opacity="0.5";
    document.getElementById("div2").style.pointerEvents="none";
    document.getElementById("div3").style.opacity="0.5";
    document.getElementById("div3").style.pointerEvents="none";
    document.getElementById("div4").style.opacity="0.5";
    document.getElementById("div4").style.pointerEvents="none";
}

function addsim(){
    // capture the network and gn name a
    var currentdate = new Date(); 
    var datetime = currentdate.getDate() + "/"
                    + (currentdate.getMonth()+1)  + "/" 
                    + currentdate.getFullYear() + " @ "  
                    + currentdate.getHours() + ":"  
                    + currentdate.getMinutes() + ":" 
                    + currentdate.getSeconds();

    $('.runitem').attr('checked', false);
    var simname = $('#simname').val();
    simname = simname+" ["+datetime+"]";

    //store current NK etc.
    var swnval = parseInt($('#swnval').val());
    var swkval = parseInt($('#swkval').val());
    var swbval = parseFloat($('#swbval').val());
    var nval = parseInt($('#nval').val());
    var kval = parseInt($('#kval').val());
    if (isNaN(swnval)||swnval<1){alert ('Value for N must be a positive integer'); return;}
    if (isNaN(swkval)||swkval<1){alert ('Value for K must be a positive integer'); return;}
    if (isNaN(swbval)||swbval>1||swbval<0){alert ('Value for b must be between 0 and 1'); return;}
    if (isNaN(nval)||nval<2 || nval>10){alert ('Value for N must be a positive integer between 2 and 10'); return;}
    if (isNaN(kval)||kval<0 || kval>=nval || kval>9){alert ('Value for K must be a positive integer between 0 and 9, and must be less than N.'); return;}
    var etext="none"
    if ($('input[name=adoption]:checked').val()==1){
      etext=$('input[name=adoption]:checked').attr('id');
    }

    var listval = "<li><input type='radio' onClick='loadsim()' id='"+gn+"' value='"+simname+"' class='runitem' name='fu' checked>"+simname+"<br>";
    var listdeets = "N: "+nval+", K: "+kval+", n: "+swnval+", k: "+swkval+", b: "+swbval+", copy error: "+etext+"</li>";
    var rlist = document.getElementById('rlist');
    rlist.insertAdjacentHTML( 'beforeend', listval+listdeets );
    

}

function dofunction(timestep) {

    var color = d3.scaleLinear().domain([0,1]).range(["#fff","#e16e41"]);
    
    var nlength = swgraph[gn][0].nodes.length;
    for (var i=0; i<nlength; i++){
      var nid = "node"+i.toString();
      var nidref = document.getElementById(nid);
      var nval = swgraph[gn][timestep].nodes[i].value;
      var ncolor = color(nval)
      nidref.setAttribute("style", "fill:"+ncolor);
      nidref.setAttribute("r", 12*nval);
    }
    
}


function initialize(graph,cind){
    var svg = d3.select("#svg1"),
        width = +svg.attr("width"),
        height = +svg.attr("height");

    var color = d3.scaleLinear().domain([0,1]).range(["#fff","#e16e41"]);
    if (cind==1){
      var color = d3.scaleLinear().domain([0,1]).range(["#aaa","#777"]);  
    }
    
    
    var simulation = d3.forceSimulation()
        .force("link", d3.forceLink().id(function(d) { return d.id; }))
        .force("charge", d3.forceManyBody())
        .force("center", d3.forceCenter(width / 2, height / 2));

    loaddata(graph) 


    function loaddata(graph) {
        
        if (graph==null){
            return;
        }
        // delete existing nodes/links
    var svg = d3.select("#svg1")
        s = svg.selectAll("*")
        s = s.remove()
        // svg.selectAll("g").remove(); //

      var link = svg.append("g")
          .attr("class", "links")
        .selectAll("line")
        .data(graph.edges)
        .enter().append("line");
          // .attr("stroke-width", function(d) { return Math.sqrt(d.value); });

// console.log(graph.nodes)
// console.log(graph.nodes[0])

    var gnodes = svg.selectAll('g.gnode')
      .data(graph.nodes)
      .enter()
      .append('g')
      .classed('gnode', true)
      .call(d3.drag()
          .on("start", dragstarted)
          .on("drag", dragged)
          .on("end", dragended));

    var fruits = ["Apple", "Orange", "Banana", "Grape"];

    // Add one circle in each group
    var node = gnodes.append("circle")
      .attr("class", "node")
      .attr("id", function(d) { return "node"+d.id })
      .attr("r", function(d) { return 12*(d.value); })
      .style("fill", function(d) { return color(d.value); })
      


  node.append("title")
        .text(function(d) { return "value: "+d.value.toFixed(2); });

      // Append the labels to each group
      var labels = gnodes.append("text")
            .attr("dx", 12)
            .attr("dy", ".35em")
              .text(function(d) { return d.id; });

        simulation
            .nodes(graph.nodes)
            .on("tick", ticked);

        simulation.force("link")
            .links(graph.edges);

        function ticked() {
          link
              .attr("x1", function(d) { return d.source.x; })
              .attr("y1", function(d) { return d.source.y; })
              .attr("x2", function(d) { return d.target.x; })
              .attr("y2", function(d) { return d.target.y; });

          // Translate the groups
            gnodes.attr("transform", function(d) { 
              return 'translate(' + [d.x, d.y] + ')'; 
            });
        }

};

function dragstarted(d) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d.fx = d.x;
  d.fy = d.y;
}

function dragged(d) {
  d.fx = d3.event.x;
  d.fy = d3.event.y;
}

function dragended(d) {
  if (!d3.event.active) simulation.alphaTarget(0);
  d.fx = null;
  d.fy = null;
}

}



