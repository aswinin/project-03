This project has two components.


1. Website

run index.html, within the “/project source files/website" folder.

Alternatively, visit http://web.mit.edu/cjfu/www/NKSimulator/


2. Python code to generate NK files

If you want to see how the NK landscapes were generated, run “/project source files/generatenk.py”.

This will return text files containing the values of different binary strings, for every value of N and K specified in the file.
