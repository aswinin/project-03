// Import the interface to Tessel hardware
var tessel = require('tessel');
var os = require('os');
var fs = require('fs');
var url = require('url');
var http = require('http');
var mysql = require("mysql");
var express    = require("express");
var av = require('tessel-av');
var cors = require('cors');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

var captured_image_data = null;

var app = express();

app.use(cors());

var port = 8082;

var ip_address = require('os').networkInterfaces().wlan0[0].address;

var camera = new av.Camera({
  width: 320,
  height: 240,
});

app.set('port', (process.env.PORT || port))

app.get('/captureImage', function(request, response) {

    console.log("Request Received at Camera");

    var capture = camera.capture();	

    console.log("Captured Image");

    capture.on('data', function(data) {

      console.log("Capturing Image");

      captured_image_data = data;
      
        var base64data = new Buffer(captured_image_data, 'binary').toString('base64');

        var httpPost = new XMLHttpRequest();
        var path = "http://ec2-35-162-90-118.us-west-2.compute.amazonaws.com/submitImage";
        var send_data = JSON.stringify({'image': base64data});
        httpPost.onreadystatechange = function(err) {
            if (httpPost.readyState == 4 && httpPost.status == 200){
                console.log("Image Send 200"); 
            } else {
                console.log(err);
            }
        };
    
    httpPost.open("POST", path, true);
    httpPost.setRequestHeader('Content-Type', 'application/json');  
    console.log(" Sending Image Data to AWS");
    httpPost.send(send_data);
    
    });

    capture.pipe(response);
    response.writeHead(200, { "Content-Type": "image/jpg" });
})

app.listen(app.get('port'), function() {
  console.log("Node app is running at " +  ip_address + app.get('port'))
})


/*     

app.get('/analyzeImage', function(request, response) {

  console.log("Analyze Image request received ");

  if (captured_image_data != null ) {

    /* var base64data = new Buffer(captured_image_data, 'binary').toString('base64');

            var httpPost = new XMLHttpRequest();
        var path = "http://ec2-35-162-90-118.us-west-2.compute.amazonaws.com/analyze";
        var send_data = JSON.stringify({image: base64data});
    httpPost.onreadystatechange = function(err) {
            if (httpPost.readyState == 4 && httpPost.status == 200){
                console.log("Image Send 200"); 
            } else {
                console.log(err);
            }
        };
    
    httpPost.open("POST", path, true);
    httpPost.setRequestHeader('Content-Type', 'application/json');  
         console.log(" Sending Image Data to AWS");
    httpPost.send(send_data);
     console.log(" send " + send_data); */

  /*  response.writeHead(200, { "Content-Type": "application/octet-stream" });

    response.send(captured_image_data);

  } else {

    response.writeHead(200, { "Content-Type": "text/plain" });

    response.send('No Image');
  }

}) */


     //fs.writeFile(path.join(__dirname, 'captures/captured-via-data-event.jpg'), data);

 /* var reader = new FileReader();
       var dataURL = "";
       reader.onload = function(){
      dataURL = reader.result;
      console.log ("Base 64 Data URL :" + dataURL);
          reader.readAsDataURL(data); }*/