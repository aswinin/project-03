var http = require('http');
var https = require('https');
var os = require('os');
var fs = require('fs');
var url = require('url');
var mysql = require("mysql");
var express    = require("express");
var bodyParser = require('body-parser');
var express = require('express');
var sync = require('synchronize');
var cors = require('cors');

var AWS = require('aws-sdk');

AWS.config.update({
  accessKeyId: 'AKIAJAUFNEZ2O57PI6HA',
  secretAccessKey: '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',
  region: 'us-east-1'
});

var sns = new AWS.SNS();

var app = express();
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); 

app.set('port', (process.env.PORT || 8080))
app.use(express.static(__dirname + '/public'))
app.use(cors({origin: '*'}));

/// DB Connection //

var con = mysql.createConnection({
  host: 'team-match-now.cyrm1j58aafh.us-west-2.rds.amazonaws.com',
  port: '3306',
  user: 'match_now',
  password: 'Transformation#2016',
  database : 'match_now'
});

con.connect(function(err){
  if(err){
    console.log('Error connecting to Db: ' + err);
  } else {
  console.log('Connection established');
}
});

///////////////////

var similar_per_id = null;
var customer_id = null;
var customer_info = null;
var persisted_id = null;
var buffer_data = null;
var imageBase64data = null;
var current_emotion = null;
var response_1 = null;
var table_att_response = null;
var customer_update_feedback = null;
var update_order_feedback = null;

///////////////////

app.get('/customer.html', function(request, response) {

     console.log(" Display customer.html ");

    response.writeHead(200, {"Content-Type": "text/html"});

    fs.readFile(__dirname + 'ui_customer_info/UI_customer_feedback.html', function (err, content) {
      if (err) {
        throw err;
      }
      response.end(content);
    });
})

app.get('/receptionist.html', function(request, response) {

     console.log(" Display receptionist.html ");

    response.writeHead(200, {"Content-Type": "text/html"});

    fs.readFile(__dirname + 'ui_receptionist/UI_face_match.html', function (err, content) {
      if (err) {
        throw err;
      }
      response.end(content);
    });
})

app.get('/table_attendant.html', function(request, response) {

     console.log(" Display table_attendant.html ");

    response.writeHead(200, {"Content-Type": "text/html"});

    fs.readFile(__dirname + 'ui_table_attendant/UI_customer_update.html', function (err, content) {
      if (err) {
        throw err;
      }
      response.end(content);
    });
})


app.post('/submitImage', function(req, response) {

     console.log(" Submit Image Data requested");

     var imageData = '';

      if(req.body != null) 
      {
         imageBase64data = req.body.image;
      }

    response.writeHead(200, {"Content-Type": "text/html"});

    response.end();
});


app.post('/analyze', function(req, res) {

      console.log ("Processing Image");
      
      similar_per_id = null;

      console.log("Analyzing Image: " + imageBase64data);

      response_1 = res;

      response_1.writeHead(200, {"Content-Type": "application/json"});     

      if(imageBase64data != null)
           processImage(imageBase64data);

 });

app.post('/sendSMS', function(req, res) {

      var message = '';
      var number = '';

      if(req.body != null) 
      {
         message = req.body.message;
         number = req.body.number;

         send_sms(message,number);
      }

      res.writeHead(200, {"Content-Type": "text/plain"});

      res.end();
 });


//////////////////////////////////////////////////////////////

app.get('/tableAttendantInfo', function(req, res) {
 
       table_att_response = res;
       var unique_id = null;

      con.query('SELECT DISTINCT Id FROM Table_attendant', [], function(err,res){
      if(err) throw err;


      unique_id = res;
       
      con.query('SELECT TA_Name, Contact FROM Table_attendant Where Id = ?', [unique_id], function(err,res){
      if(err) throw err;

            table_att_response.writeHead(200, {"Content-Type": "text/plain"});
            table_att_response.end(res);
      
     });

     });

 });

////////////////////////////////////////////////////////////////

app.post('/updateFeedback', function(req, res) {

      var feedback = '';
      var customer_id = '';
      var table_attendant = '';
      var date_today = new Date();

      customer_update_feedback = res;


      if(req.body != null) 
      {
         feedback = req.body.feedback;
         customer_id = req.body.customer_id;
         table_attendant = req.body.table_attendant_id;

      }


      var feedback = {Id:table_attendant, Cust_id_served:customer_id, Cust_score: feedback};
      con.query('INSERT INTO Table_attendant SET ?', feedback, function(err,res){
      if(err) throw err;

      customer_update_feedback.writeHead(200, {"Content-Type": "text/plain"});

      customer_update_feedback.end();

      //console.log('Last insert ID:', res.insertId);
       });


 });


////////////////////////////////////////////////////////////////////////////////////


app.post('/updateOrder', function(req, res) {

      var dishes_ordered = '';
      var drinks_ordered = '';
      var customer_id = '';
      var table_attendant = '';
      var emotion = '';
      var date_today = new Date();

      update_order_feedback = res;


      if(req.body != null) 
      {
         dishes_ordered = req.body.dishes_ordered;
         customer_id = req.body.customer_id;
         drinks_ordered = req.body.drinks_ordered;
         table_attendant = req.body.table_attendant;
         emotion = req.body.emotion;
      }


      var order_details = {Cust_id:customer_id, Visit: date_today.toISOString().split('T')[0], Emotion: emotion, Dishes_ordered:dishes_ordered , Drinks_ordered:drinks_ordered};

      con.query('INSERT INTO Customer_transaction SET ?', order_details, function(err,res){
      if(err) throw err;

      update_order_feedback.writeHead(200, {"Content-Type": "text/plain"});

      update_order_feedback.end();

      //console.log('Last insert ID:', res.insertId);
       });


 });



////////////////////////////////////////////////////////////////

app.listen(app.get('port'), function() {
  console.log("Node app is running at localhost:" + app.get('port'))
})

function processImage (image_data) {

      var detected_face_id = '';
  
                var parsedURL =  url.parse("https://api.projectoxford.ai/face/v1.0/detect");

               buffer_data = new Buffer(image_data, 'base64');

                var options = {

                        host: parsedURL.host,

                        path: '/face/v1.0/detect',

                        headers: {
                                'Content-Type':'application/octet-stream',
                                'Content-Length':buffer_data.length,
                                'Ocp-Apim-Subscription-Key': "24bbe36547504ae6a296eb2125f1c551",
                        },


                        method:'POST', 
                        
                        params: {
                      "returnFaceId": "true",
                      "returnFaceLandmarks": "false"
                       }
                     };

                var callback = function(response){
                        var str = '';

                        response.on('data', function(chunk){
                                str+= chunk;
                        });

                        response.on('end', function(){

                                var obj = JSON.parse(str);

                                //console.log("Detection Response: " + str);

                                if (obj != null && obj.length > 0) {


                                  if (obj[0].hasOwnProperty('faceId')) {   
                                
                                     detected_face_id = obj[0].faceId;

                                     console.log("Detected Face Id captured in Image: " + detected_face_id);

                                     //console.log("Face Id Detected: " + detected_face_id);

                                     //persist_face(detected_face_id, buffer_data);

                                     var similar_persisted_id =  find_similar(detected_face_id,buffer_data);

                                     // console.log("Similar Persisted Id from Threading:" + similar_persisted_id);
                              }  else {

                              	response_1.end();
                              }
                            }

                        });

                };

                var post_req = https.request(options, callback);
                post_req.write(buffer_data);
                post_req.end();

                console.log ("Face Detection Request Send");

          ////////////////////


    }


    function find_similar (faceId, buffer_data)

    {
          var parsedURL =  url.parse("https://api.projectoxford.ai/face/v1.0/findsimilars");

            var options = {

                        host: parsedURL.host,

                        path: '/face/v1.0/findsimilars',

                        headers: {
                                'Content-Type':'application/json',
                                'Ocp-Apim-Subscription-Key': "24bbe36547504ae6a296eb2125f1c551",
                        },

                        method:'POST', 
                        
                       params: {
                        "faceListId": "match_now",
                      }

                     };
                     
                     var flag = false;

                      var callback = function(response){
                        var str = '';

                        response.on('data', function(chunk){
                                str+= chunk;
                        });

                        response.on('end', function(){

                                var obj = JSON.parse(str);

                                console.log("Found Similar Response: " + str);

                                if (obj != null) {


                                  if (obj.length > 0 && obj[0].hasOwnProperty('persistedFaceId')) {   

                                     var highest_conf = { confidence:0,id:''};

                                    for (var i=0; i<obj.length;i++)
                                    {
                                      if(highest_conf.confidence == 0) {
                                        highest_conf.confidence = obj[i].confidence;
                                        highest_conf.id = obj[i].persistedFaceId;
                                      }
                                      if(obj[i].confidence > highest_conf.confidence) {
                                        highest_conf.confidence = obj[i].confidence;
                                        highest_conf.id = obj[i].persistedFaceId;
                                      }
                                    }
                                
                                     //persisted_face_id = obj[0].persistedFaceId;

                                     persisted_face_id  = highest_conf.id;

                                     console.log("Persisted Similar Face Id found : " + persisted_face_id); 

                                     similar_per_id =   persisted_face_id;

                                     console.log("Storing Detected Image ID: " + faceId);  

                                     persist_face(faceId, buffer_data);     

                                    return persisted_face_id;

                                  } else {

                                    response_1.end();

                                    return null;

                                  }
                            }

                            flag = true;

                        });

                      };

        
                var post_req = https.request(options, callback);

                var req_body = { 
                  "faceId":faceId,
                  "faceListId":"match_now",  
                 "maxNumOfCandidatesReturned":50,
                  "mode": "matchPerson"
                };

                post_req.write(JSON.stringify(req_body));
                post_req.end();

                while(flag) {require('deasync').sleep(100);

            }

  }

    function persist_face (faceId, buffer_data)

    {
          var parsedURL =  url.parse("https://api.projectoxford.ai/face/v1.0/facelists/match_now/persistedFaces");

            var options = {

                        host: parsedURL.host,

                        path: '/face/v1.0/facelists/match_now/persistedFaces',

                        headers: {
                                'Content-Type':'application/octet-stream',
                                'Content-Length':buffer_data.length,
                                'Ocp-Apim-Subscription-Key': "24bbe36547504ae6a296eb2125f1c551",
                        },

                        method:'POST',  

                     };

                      var callback = function(response){
                        var str = '';

                        response.on('data', function(chunk){
                                str+= chunk;
                        });

                        response.on('end', function(){

                                var obj = JSON.parse(str);

                                console.log("Store Image Response " + str);

                                if (obj != null) {


                                  if (obj.hasOwnProperty('persistedFaceId')) {   
                                
                                     persisted_id = obj.persistedFaceId;

                                     console.log("Persisted Face Id created: " + persisted_id);

                                    console.log("Detecting Emotion of Detected Image ID: " + faceId);  

                                    fetch_emotion(faceId, buffer_data);

                                    return persisted_id;

                               }  else {


                                    fetch_emotion(faceId, buffer_data);

                                    return null;
                               }

                            }


                        });

                      };
        
                var post_req = https.request(options, callback);

                post_req.write(buffer_data);
                post_req.end();

    }

  function fetch_emotion (faceId, buffer_data)

    {
          var parsedURL =  url.parse("https://api.projectoxford.ai/emotion/v1.0/recognize");

            var options = {

                        host: parsedURL.host,

                        path: '/emotion/v1.0/recognize',

                        headers: {
                                'Content-Type':'application/octet-stream',
                                'Content-Length':buffer_data.length,
                                'Ocp-Apim-Subscription-Key': "754620b46cc644dcbadaa477a2b21eb5",
                        },

                        method:'POST',  

                     };

                      var callback = function(response){
                        var str = '';

                        response.on('data', function(chunk){
                                str+= chunk;
                        });

                        response.on('end', function(){

                                var obj = JSON.parse(str);

                                console.log("Emotion API response " + str);

                                if (obj != null && obj.length > 0) {

                                  if (obj[0].hasOwnProperty('scores')) {  

                                     //anger = obj[0].scores.anger;

                                     var scores_list = obj[0].scores;

                                     var max = Math.max.apply(null,Object.keys(scores_list).map(function(x){ return scores_list[x] }));

                                     current_emotion = Object.keys(scores_list).filter(function(x){ return scores_list[x] == max; })[0];

                                     ////////////////////////////////////////////////////


                                     console.log(" Similar Persisted Id in Emotion API: " + similar_per_id);
                                                        

                                    if (similar_per_id != null) {
                                     
                                     // Fetch Existing Customer Details 

                                    console.log("Quering DB");

                                     db(similar_per_id);

                                    } else {

                                    // New Customer	

                                   response_1.end();


                                    }

                                    return true;

                               }  else {

                                    return false;
                               }  
                            }

                        });

                      };
        
                var post_req = https.request(options, callback);

                post_req.write(buffer_data);
                post_req.end();

    }

    
    function db(image_id)
    {
    	                var callback_1 = function(err,rows){
  										if(err) throw err;

  										console.log('Data received from Db:\n');
  										console.log(rows);

  										if (rows.length > 0)  {

  										customer_id = rows[0].Cust_id;	
                      console.log('Customer Id fetched: ' + customer_id);

                                   // Fetch from Customer Transactions Table 

                      var callback_2 = function(err,rows) {

                         if(err) throw err;

  										console.log('Customer Data received from Db:\n');
  										console.log(rows);
  										 
  										customer_info = {
  											                   'Customer_Id': customer_id,
                                           'First_Name': rows[0].First_Name,
                                           'Last_Name': rows[0].Last_Name,
                                            'Sex': rows[0].Sex,
                                            'Food_Pref': rows[0].Food_Pref,
                                            'Fav_TA': rows[0].Fav_TA
  										};

                    console.log("Customer Info Object: " + JSON.stringify(customer_info));

                    var callback_3 = function(err,rows) {
                                     
                                     if(err) throw err;

                      console.log('Data received from Db:\n');
                      console.log(rows);

                      customer_info['Dishes_ordered'] = rows[0].Dishes_ordered;
                      customer_info['Drinks_ordered'] = rows[0].Drinks_ordered;
                      customer_info['Past_Emotion'] = rows[0].Emotion;

                      var date = new Date();
                      var month = date.getMonth();

                      current_month = 0;
                      current_month_1 = 0;
                      current_month_2 = 0;


                      for(var i = 0; i < rows.length; i++) {

                        if(rows[i].Visit != null) {

                        if(rows[i].Visit.getMonth() == month)
                          current_month = current_month + 1;
                        if(rows[i].Visit.getMonth() == (month - 1))
                          current_month_1 = current_month_1 + 1;
                        if(rows[i].Visit.getMonth() == (month - 2))
                          current_month_2 = current_month_2 + 1;
                      }

                        }
                            
                      customer_info['current_month'] = current_month;
                      customer_info['current_month_1'] = current_month_1;
                      customer_info['current_month_2'] = current_month_2;
                      customer_info['current_emotion'] = current_emotion;

                      console.log("Sending Response: " + JSON.stringify(customer_info));

                      response_1.end(JSON.stringify(customer_info));

                      saveImageId(customer_id,buffer_data,persisted_id);

                      };
                      
                                   con.query('SELECT * FROM Customer_transaction Where Cust_id = ? ORDER BY Visit DESC',[customer_id],callback_3); 

                    };

                      console.log("Quering Customer Id: " + customer_id);

  										con.query('SELECT * FROM Customer_table Where Cust_id = ?',[customer_id],callback_2);

                              } else {

                              		response_1.end();
                              }
										};

    	              con.query('SELECT Cust_id FROM Image_testblob Where image_id = ?',[image_id],callback_1);
    }

    function send_sms (message, sms) {

     var sns = new AWS.SNS();

      var params = {
        Message: message,
        MessageStructure: 'string',
        PhoneNumber: sms
      };

      sns.publish(params, function(err, data) {
      if (err) console.log(err, err.stack); // an error occurred
      else     console.log(data);           // successful response
      });

    }

    function saveImageId(cust_id,buf_data,persist_id) {

     var image_cust_id = { Cust_id: cust_id, Image_id: persist_id, image: buf_data };
    con.query('INSERT INTO Image_testblob SET ?', image_cust_id, function(err,res){
      if(err) throw err;
      console.log('Insert Image_testblob ID:', res.insertId);
     });

    }


