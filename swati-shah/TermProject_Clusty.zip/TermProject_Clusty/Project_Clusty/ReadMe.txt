Project Clusty Installation Instructions

Project Description: 
Clusty is a news search engine which gathers relevant news from NY Times and Guardian. News is categorize afterwards and will be assigned a color coding as per topic association using LDA Clustering algorithm.

Project Requirement:
1. Should use Google Chrome for animations to work.
2. All the files present in Project.zip should be downloaded to the local directory.
3. Last but not the least, Connectivity to Internet is required

Installation Steps: Please follow below steps sequentially
1. Unzip the file named ProjectClusty.zip
2. Go to the folder html and run Clusty.html
3. This will open up a chrome window where you can enter the search keyword. The window will finally show you the relevant news with similar topics clustered in same color encoding. 

Demo of the project
Demo can be found at URL:https://youtu.be/OL3ilaxkPa4

 


  

